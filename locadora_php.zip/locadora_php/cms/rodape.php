<footer id="nome_desenvolvedor">
    <span>Desenvolvido por: Pablo Kauê</span>
</footer>