<!doctype html>

<html>
    <head>
        <title>CMS - Sitema de Gerenciamento do Site</title>
        <link href="css/cms.css" type="text/css" rel="stylesheet">
    </head>
    <body>
        <div id="caixa_conteudo">
            <div id="conteudo" class="center">
                <div class="titulo_logo">
                    <h1 class="titulo">CMS </h1><h2 class="subtitulo">- Sistema de Gerenciamento do Site</h2>
                </div>
                <figure class="logo">
                        <img src="img/Acme.png">
                </figure>
                <div class="caixa_adm">
                    <div class="opcao_adm">
                        <figure class="img_adm">
                            
                        </figure>
                        <div class="texto_adm">
                            <span>Adm. Conteúdo</span>
                        </div>
                    </div>
                     <div class="opcao_adm">
                        <figure class="img_adm">
                            
                        </figure>
                        <div class="texto_adm">
                            <span>Adm. Conteúdo</span>
                        </div>
                    </div>
                     <div class="opcao_adm">
                        <figure class="img_adm">
                            
                        </figure>
                        <div class="texto_adm">
                            <span>Adm. Conteúdo</span>
                        </div>
                    </div>
                     <div class="opcao_adm">
                        <figure class="img_adm">
                            
                        </figure>
                        <div class="texto_adm">
                            <span>Adm. Conteúdo</span>
                        </div>
                    </div>
                </div>
                <div class="area_adm">
                    <div class="bem_vindo">
                        <span>Bem vindo, XXXXXX.</span>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>